//
//  AppDelegate.h
//  PhotoViewer
//
//  Created by Jeremy Wang on 9/24/14.
//  Copyright (c) 2014 Jeremy Wang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

